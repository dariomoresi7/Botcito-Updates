@echo off
TITLE Bot.MauiBlazor - Environment Provisioning Script
SETLOCAL Enabledelayedexpansion

:: Check for Administrative Privileges
net session >nul 2>&1
if %errorLevel% == 0 (
    echo ============================================================
    echo           INITIALIZING ENVIRONMENT PROVISIONING              
    echo ============================================================
    echo.
    echo [STATUS] Administrative privileges verified.
    echo [STEP 1] Injecting Deployment Authority Certificate into Trusted Stores...
    echo.
    
    :: Descarga el certificado a la carpeta temporal e importa nativamente en Root y TrustedPeople
    powershell -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; $certPath = Join-Path $env:TEMP 'Botcito.cer'; Invoke-WebRequest 'https://github.com/dariomoresi7/Botcito-Updates/releases/latest/download/Botcito.cer' -OutFile $certPath -UseBasicParsing; Import-Certificate -FilePath $certPath -CertStoreLocation 'Cert:\LocalMachine\Root' | Out-Null; Import-Certificate -FilePath $certPath -CertStoreLocation 'Cert:\LocalMachine\TrustedPeople' | Out-Null; Remove-Item $certPath -Force"
    
    if !errorlevel! equ 0 (
        echo.
        echo [SUCCESS] Security provisioning completed successfully.
        echo [STEP 2] Launching AppInstaller Engine via PowerShell Bypass...
        echo.
        
        :: Instala el .appinstaller directo desde la web corporativa/repositorio
        powershell -Command "Add-AppxPackage -AppInstallerFile 'https://github.com/dariomoresi7/Botcito-Updates/releases/latest/download/Bot.MauiBlazor.appinstaller'"
        
        echo.
        echo [STATUS] Deployment process delegated to Windows AppInstaller subsystem.
        echo [STATUS] You may safely close this terminal console window.
        echo.
    ) else (
        echo.
        echo [ERROR] Certificate provisioning failed. Internal error code: !errorlevel!
        echo Please ensure you have an active internet connection.
        echo.
    )
    pause
) else (
    echo ============================================================
    echo      CRITICAL ERROR: SYSTEM ACCESS PRIVILEGES REQUIRED      
    echo ============================================================
    echo.
    echo This provisioning script requires elevated system access scopes.
    echo.
    echo [INSTRUCTION]:
    echo 1. Right-click on this file
    echo 2. Select "Run as Administrator" from the Windows context menu.
    echo.
    echo ============================================================
    pause
)
