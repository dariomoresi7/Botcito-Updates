@echo off
TITLE Bot.MauiBlazor - Environment Provisioning Script
SETLOCAL Enabledelayedexpansion

:: Check for Administrative Privileges
net session >nul 2>&1
if %errorLevel% == 0 (
    echo ============================================================
    echo           INITIALIZING ENVIRONMENT PROVISIONING              
    echo ============================================================
    echo.
    echo [STATUS] Administrative privileges verified.
    echo [STEP 1] Injecting Deployment Authority Certificate into Trusted Root Store...
    echo.
    
    :: Registering the .cer certificate into Windows Trusted Root Storage
    certutil -addstore "Root" "%~dp0Bot.MauiBlazor_1.0.0.0_x64.cer"
    
    if !errorlevel! equ 0 (
        echo.
        echo [SUCCESS] Security provisioning completed successfully.
        echo [STEP 2] Launching AppInstaller Engine via PowerShell Bypass...
        echo.
        
        :: SOLUCIÓN DEFINITIVA: Usa PowerShell para instalar el .appinstaller directo desde la web
        powershell -Command "Add-AppxPackage -AppInstallerFile 'https://dariomoresi7.github.io/Botcito-Updates/Bot.MauiBlazor.appinstaller'"
        
        echo.
        echo [STATUS] Deployment process delegated to Windows AppInstaller subsystem.
        echo [STATUS] You may safely close this terminal console window.
        echo.
    ) else (
        echo.
        echo [ERROR] Certificate registration failed. Internal error code: !errorlevel!
        echo Please ensure the .cer file exists within the same execution path.
        echo.
    )
    pause
) else (
    echo ============================================================
    echo      CRITICAL ERROR: SYSTEM ACCESS PRIVILEGES REQUIRED      
    echo ============================================================
    echo.
    echo This provisioning script requires elevated system access scopes.
    echo.
    echo [INSTRUCTION]:
    echo 1. Right-click on this file
    echo 2. Select "Run as Administrator" from the Windows context menu.
    echo.
    echo ============================================================
    pause
)